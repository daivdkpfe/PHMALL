/**
 * Created by Administrator on 2017/9/15.
 */
var express = require('express');
var router = express.Router();
var io = require('socket.io');
var fs = require("fs");
/* GET home page. */



router.post('/', function(req, res, next) {
    var result={};
    if(req.session.sign && req.session.m_id)
    {

        var uid=req.body.uid;
        var m_id=req.session.m_id;
        console.log(req.session.m_id);
        var sql=[];
        sql.push(uid);
        sql.push(m_id);
        sqlQueryMore("SELECT uid,ordersn,status,goods_rest_amount FROM `mvm_order_info` WHERE uid = ? AND username=? LIMIT 1",sql,function (err,val,xx) {
            if(val.length<=0)
            {
                result['status']='Fail';
                result['err']="检索不到指定订单，请联系管理员";
                res.json(result);
            }
            else
            {
                if(val[0]['status']!=3 || val[0]['status']!=4)
                {

                    sqlQueryMore("UPDATE `mvm_order_info` SET status='5' WHERE uid=? and username=?",sql,function (err,vals,xx) {
                        if(err) logger.info("Caught exception:"+err);
                        result['status']='Success';
                        result['err']="确认收货成功";
                        res.json(result);
                    });
                }
                else{

                    result['status']='Fail';
                    result['err']="无法修改订单状态";
                    res.json(result);

                }
            }

        });
    }
    else
    {
        console.log(req.session.m_id);
        result['status']='Fail';
        result['err']="No Login";
        res.json(result);
    }

});

module.exports = router;
