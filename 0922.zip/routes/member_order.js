/**
 * Created by Administrator on 2017/9/14.
 */
var express = require('express');
var router = express.Router();
var io = require('socket.io');
var fs = require("fs");
/* GET home page. */



router.post('/', function(req, res, next) {

    if(req.session.sign && req.session.m_id)
    {
        var sql=[];
        var sqlstr="";
        sql.push(req.session.m_id);

        if(req.body.status!=0)
        {
            sql.push(req.body.status);
            sqlstr=" and o.status = ?";
        }


        sqlQueryMore("SELECT o.uid,o.status,o.goods_amount,g.m_uid,g.shop_name FROM `mvm_order_info` o FORCE INDEX (`username`) left join `mvm_member_shop` g on o.supplier_id=g.m_uid WHERE username=? "+sqlstr+" ORDER BY addtime DESC LIMIT "+req.body.start+",10",sql,function (err,vals,xx){
            var i=0;//循環计数

            if(err) logger.info("Caught exception:"+err);
            vals.forEach(function (item,index) {
                vals[index]['all_number']=0;
                vals[index]['status_num']=vals[index]['status'];
                vals[index]['status']=statusArr[item['status']];
                var sql1=[];
                sql1.push(item['uid']);
                sqlQueryMore("SELECT uid,g_uid,goods_name,goods_attr,module,supplier_id,buy_price,rest_price,buy_number,buy_point,goods_table,status FROM `mvm_order_goods` where order_id=?",sql1,function (err,val,xx) {
                    if(err) logger.info("Caught exception:"+err);

                    vals[index]['goods_list']=val;
                    console.log(val);
                    val.forEach(function (items,indexs) {

                        vals[index]['all_number']=vals[index]['all_number']+items['buy_number'];
                        sql2=[];
                        sql2.push(items['g_uid']);
                        sqlQueryMore("select * from "+items['goods_table']+" where uid=?",sql2,function (err,va,xx) {

                            i++;
                            if(va.length>0)
                            {
                                vals[index]['goods_list'][indexs]['goods_file']=va[0]['goods_file1'];
                            }
                            if(i==vals.length)
                            {
                                res.json(vals);
                            }
                        });



                    });


                });



            });




        });
    }
    else
    {
        var token_data={};
        token_data['status']='No Login';
        
        res.json(token_data);
    }
});
router.get('/', function(req, res, next) {
    res.render('member_order', { title: 'Express' });
});
module.exports = router;
