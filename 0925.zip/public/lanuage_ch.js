/**
 * Created by Administrator on 2017/9/15.
 */
var lanuage={};
lanuage['xx']=1;
