/**
 * Created by Administrator on 2017/9/24.
 */
var express = require('express');
var router = express.Router();
var io = require('socket.io');
var fs = require("fs");
/* GET home page. */



router.get('/', function(req, res, next) {
    console.log(":ss");

        if (req.session.sign && req.session.m_id) {

            res.render('comment', {title: 'PHMALL',allow_uid:req.query.allow_uid});

        }
        else
        {

            res.redirect('../login');//重定向
        }

});

router.post('/',function (req,res,next) {

    var comment_allow_uid=[];
    comment_allow_uid.push(req.body.uid);
    sqlQueryMore("select roll,uid,from_id,to_id,shop_name,ordersn from `mvm_comment_allow` where roll='0' and uid=?",comment_allow_uid,function (err,comment_allow,xx) {
        if(err) logger.info("Caught exception:"+err);
        console.log(comment_allow);
        if(comment_allow.length>0)
        {
            sqlQueryMore('select uid from `mvm_order_info` where ordersn="'+comment_allow[0].ordersn+'"',comment_allow_uid,function (errs,orderinfo,xx) {
                if(errs) logger.info("Caught exception:"+errs);
                if(orderinfo.length>0)
                {
                    sqlQueryMore('select * from `mvm_order_goods` where order_id='+orderinfo[0].uid,comment_allow_uid,function (errss,ordergoods,xx) {

                            if(errss) logger.info("Caught exception:"+errss);
                            if(ordergoods.length>0)
                            {
                                var s=0;
                                ordergoods.forEach(function (item,index) {
                                    sqlQueryMore("select goods_name,goods_file1 from `"+item.goods_table+"`where uid="+item.g_uid,comment_allow_uid,function (errsss,goodsinfo,xx) {
                                        if(errsss) logger.info("Caught exception:"+errsss);
                                        if(goodsinfo.length>0)
                                        {
                                            ordergoods[index]['goods_name']=goodsinfo[0].goods_name;
                                            ordergoods[index]['goods_file1']=goodsinfo[0].goods_file1;
                                            comment_allow[0]['goods_list']=ordergoods;
                                            s++;
                                            if(s==ordergoods.length)
                                            {
                                                res.json(comment_allow);
                                            }
                                        }
                                    })
                                });
                            }
                            else
                            {
                                comment_allow[0]['goods_list']="";
                                res.json(comment_allow);
                            }



                    });

                }
                else
                {
                    res.json("找不到指定訂單，請聯繫管理員");
                }
            });


        }
        else
        {
            res.json("找不到指定訂單，請聯繫管理員");
        }
    });
});

router.post('/comment',function (req,res,next) {
    console.log(req.body.xx);
    console.log("xx");
});

module.exports = router;
